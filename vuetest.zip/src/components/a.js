export const a = '请您点击 <script>alert(1)</script> 为您服务。'
